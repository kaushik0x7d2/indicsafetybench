# IndicSafetyBench v3 — Review Package

Prepared for: **Sumanth Doddapaneni** (arXiv endorser; Sarvam AI / AI4Bharat / IIT Madras)
Prepared by: Kaushik Kachireddy (Independent; NYU Tandon Fall 2026 cohort)
Date: 2026-06-04
Status: Pre-arXiv preprint — soliciting feedback before submission.

---

## What to read, in what order

If you have 15 minutes, read:

1. **`paper/paper.pdf`** §1 Introduction + §4.3 (orthographic measurement-crisis finding) + §4.6 (validation results)
2. **`methodology/APPENDIX_X_RATER_FAILURES.md`** — the rater-failure taxonomy that justified the LLM-primary validation pivot

If you have an hour:

3. **`methodology/VALIDATION_VERDICT.md`** — full reasoning for the LLM-primary pivot with field-consensus citations
4. **`paper/paper.pdf`** §3.7 + Appendices X, Y, Z
5. **`results/PANEL_REPORT.md`** — the actual 2-judge κ matrix data

If you want to verify the empirical claims:

6. **`evidence_rater_failures/`** — the contaminated validator CSVs (one per language) so you can see the rubber-stamping + cross-language copy-paste patterns in raw data
7. **`evidence_orthographic/`** — the 200 gpt-oss-120b responses showing the orthographic-apostrophe failure mode
8. **`results/panel/`** — every per-call judgment record for the 2-judge ensemble

---

## What changed v2 → v3

### New findings (each defensible as a standalone contribution)

1. **§4.3 — Orthographic measurement-crisis** generalises the v2 measurement-crisis claim *beyond* Sarvam reasoning models. OpenAI's `gpt-oss-120b` (open-source 120B MoE) is the strongest refuser in our panel (95-100% LLM-judge refusal across all 7 languages) but the heuristic catches **zero** of its refusals — until a three-line regex patch adding `[''`'`]` to the apostrophe-character class lifts heuristic recall to 98%. The failure mechanism is mechanically different from Sarvam's soft-refusal pattern (orthographic vs structural). Two independent failure modes → the heuristic is brittle along *both* dimensions.

2. **Appendix X — Rater-failure taxonomy.** Two annotator-quality failure modes documented for the first time in Indic NLP: uniform 5/5 rubber-stamping (one Telugu validator, σ=0.00 across 90 items) and cross-language score copy-paste (one validator returned bit-identical score vectors across Tamil/Marathi/Kannada files — Hamming distance zero on 82 of 82 join-matched items despite genuinely language-distinct prompts). Detection signatures included.

3. **§4.6 — LLM-as-prompt-quality-validator characterisation in the multilingual adversarial regime.** Two-judge ensemble (Gemini 2.5 Pro × Sarvam-30B) on 600 items × 3 axes. Gemini shows the documented multilingual high-score bias (equivalence mean 4.91-4.99 ± 0.10-0.53 across all 7 languages); Sarvam-30B is 1.0-1.5 Likert points more critical on naturalness. Inter-judge κ collapses near zero — not from random disagreement but as the mechanical consequence of Gemini's zero variance. This is the first published per-axis per-language inter-judge κ on Indic adversarial prompts.

4. **Appendix Z — Judge-model safety-filter as access blocker.** Claude Code's Cyber Verification Program safeguard rejected our adversarial-corpus judging requests even with explicit research framing. Documented as a v3-era failure mode for future Indic red-team benchmarks to plan around.

### What stayed unchanged from v2
- §1, §2 (intro, related work) — minor wording updates only
- §4.1, §4.2 (original measurement-crisis numbers on Sarvam) — unchanged
- §5 (discussion) — extended slightly to incorporate the new §4.3 finding

### Acknowledged limitations carried into §6 + v4 roadmap
- Two-judge instead of three-judge ensemble (Claude blocked at every available route — see Appendix Z)
- Sarvam coverage uneven on naturalness (47%) due to Sarvam STARTER tier `max_tokens=4096` cap insufficient for `<think>` chains on hard items
- BharatGen Param2 self-host is pre-registered for v4 (infrastructure ready; not yet run)

---

## Where the BRL attribution lives

We include `Param2-17B-A2.4B-Thinking` results in the v4 follow-up, not v3. For v3 we still cite BharatGen in §3.5 (Models, forward-looking) and Acknowledgments per BRL §2 attribution requirement. The notice "Licensed by BharatGen under the BharatGen Research License" appears in §7 Ethics and the released code repository — see paper §7 "Model-specific licensing" paragraph.

---

## Specific feedback I would value most

1. **Is the v3 §4.6 LLM-primary framing defensible?** I made the pivot after the human pilot failed (Appendix X); the FBI 2024 reference-anchoring design choice came from your work. If this framing reads as principled rather than corner-cutting, I'll proceed to arXiv as-is. If it reads weak, I'll add the n=50/language native calibration sample (Appendix Y) before submitting.

2. **Is the orthographic §4.3 finding sufficiently novel as a v3 contribution?** I think it is (different lab, different failure mechanism than Sarvam, mechanically reproducible fix) but a fresh-eyes second opinion would help.

3. **Anything missing from the rater-failure taxonomy (Appendix X)?** The two failure modes are real and I have raw evidence in `evidence_rater_failures/`. If you've seen other failure modes at Karya/Samiksha I should add, I'll incorporate.

4. **arXiv endorsement** — happy to proceed when you've signed off on the above. The submission will reference your endorsement per arXiv policy.

---

## Repo state behind this package

- Branch: `main`
- Latest commit at time of packaging: `9546d68` (v3 §4.6 data final at Sarvam STARTER tier)
- Eleven local commits pending push to `origin/main` (will push after your feedback so any text changes go in atomically)
- Full code + data + history at https://github.com/kaushik0x7d2/indicsafetybench (private during preprint phase)

Reach me at the channel this package arrived on.
