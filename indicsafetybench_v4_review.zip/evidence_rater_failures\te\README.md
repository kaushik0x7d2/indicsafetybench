# Validation pack — Telugu (te)

## ⚠ CONTAMINATED PILOT — NOT USED IN v3 PRIMARY VALIDATION

This directory contains the Telugu validator pack we prepared and the returned scoring CSV(s) from the initial human-rating pilot. The pilot returns from this language are part of the rater-failure evidence documented in paper Appendix~X and "docs/APPENDIX_X_RATER_FAILURES.md".

**These CSVs are NOT used in the v3 corpus validation.** The v3 §4.6 validation source-of-truth is the LLM-ensemble protocol output at `data/validation/PANEL_REPORT.md` (Gemini 2.5 Pro × Sarvam-30B).

Files in this directory:

- `INSTRUCTIONS.md` — the brief we sent to the validator (Likert protocol, scoring rubric)
- `validator1_te.csv` (and `validator2_te.csv` for Telugu) — the returned scoring CSV(s); contain the rater-failure-evidence patterns
- `sample_n30.{csv,jsonl}` — the stratified sample we asked the validator(s) to score (30 prompts per attack-vector cell)
- `te_validator{1,2}_pack.zip` — packaged pack delivered to the validator(s)

## Gating

These CSVs contain per-rater scoring patterns and free-text comments. Per-rater identifying details (including verbatim free-text comments) are NOT to be redistributed under the gating policy described in the top-level `GATING.md`. Aggregate signatures (per-axis means/stds, Hamming distance across files) are publishable and the basis of the Appendix~X taxonomy.

## How to reproduce the rater-failure evidence

See `docs/APPENDIX_X_RATER_FAILURES.md` and `final/evidence_rater_failures/README.md` in the released repository for the reproducible Python snippets that compute (a) per-axis std on this file, and (b) Hamming distance between this file and the Tamil / Marathi / Kannada equivalents (only relevant for ta/mr/kn).
