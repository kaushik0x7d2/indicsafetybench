# v3 §4.6 validation results — raw data

The two-judge LLM ensemble (Gemini 2.5 Pro via Google Vertex AI × Sarvam-30B via Sarvam direct API) scored 600 items × 3 axes on the IndicSafetyBench v3 validation sample. This directory contains the aggregated tables and per-call records.

## Top-level files

| File | What it is |
|---|---|
| `PANEL_REPORT.md` | The §4.6 source-of-truth tables: per-judge per-language mean Likert; inter-judge weighted κ with bootstrap 95% CI; intra-judge α (empty — single rerun); disagreement summary. **Read this first.** |
| `panel_disagree.md` | Full per-item list of the 115 disagreements ≥ 2 Likert points. The basis for the §4.6 disagreement-taxonomy claim. |
| `panel_kappa.jsonl` | Machine-readable κ records (one line per per-axis per-language per-judge-pair cell). For reviewers who want to recompute. |

## Raw per-call records

`panel/` contains six JSONL files, one per (judge × axis):

| File | Records | Parse-OK (unique items) | Note |
|---|---:|---:|---|
| `judgments_gemini_naturalness.jsonl` | 600 | 600 (100%) | Clean |
| `judgments_gemini_equivalence.jsonl` | 844 | 600 (100%) | Includes 244 stale-fail records superseded by retry — aggregator dedupes |
| `judgments_gemini_attack_validity.jsonl` | 600 | 600 (390 real + 210 N/A direct) | Clean |
| `judgments_sarvam_naturalness.jsonl` | 1045+ | 282 (47%) | Sarvam STARTER tier `max_tokens=4096` insufficient for harder items |
| `judgments_sarvam_equivalence.jsonl` | 600 | 570 (95%) | Mostly complete |
| `judgments_sarvam_attack_validity.jsonl` | 859+ | 289 (48% of non-direct) | Same tier-cap cause |

Each record has: variant_id, language, attack_vector, category, judge_id, axis, rerun_idx, temperature, score, rationale, parse_ok, raw (first 400 chars of model output), latency_ms, prompt_tokens, completion_tokens, ts.

## How to recompute

```bash
# 1. Place the panel/ subdirectory inside data/validation/ of the indicsafetybench repo
# 2. Run the aggregator:
python -m src.validation.aggregate_panel
# 3. The PANEL_REPORT.md, panel_disagree.md, panel_kappa.jsonl are regenerated
#    byte-deterministically from the JSONL records (bootstrap seed = 2026)
```

## Sarvam coverage caveat

The Sarvam STARTER tier subscription hard-caps `max_tokens` at 4096 for `sarvam-30b` and `sarvam-105b`. Sarvam reasoning models put `<think>...</think>` blocks before their JSON answer; many Indic naturalness judgments require ≥4096 reasoning tokens before reaching the JSON. On items where reasoning overflows the cap, the model emits all its `<think>` content then gets cut off → empty visible JSON → parse fail → record not used.

A paid Sarvam tier would lift this cap. The §4.6 finding (Gemini high-score bias; Sarvam-Gemini divergence on naturalness) holds at current coverage because mean Likert and κ are computed only over parsed responses; the gaps reduce per-cell n but do not bias the central tendency.
