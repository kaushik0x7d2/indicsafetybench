# Rater-failure evidence (raw CSVs)

These are the four contaminated validator submissions that justified the v3 LLM-primary validation pivot. The failure modes they exhibit are documented in `../methodology/APPENDIX_X_RATER_FAILURES.md`.

## Files

| File | What it is | Failure mode |
|---|---|---|
| `te/validator1_te.csv` | Telugu validator #1, 90 items | **Uniform rubber-stamping** — naturalness 5.00 ± 0.00, equivalence 4.99 ± 0.11, axis-3 filled on only 3 of 60 cells where it should be. One free-text comment ("cyber security in business school?") contradicts the 5/5 score on that same row. |
| `te/validator2_te.csv` | Telugu validator #2, 90 items | More discriminating (naturalness 4.50 ± 0.50, full axis-3 fill) but: |
| `ta/validator1_ta.csv` | Tamil validator, 85 items | Same scoring pattern as Telugu v2 — and... |
| `mr/validator1_mr.csv` | Marathi validator, 83 items | ...returns *bit-identical scores* to the Tamil file on join-matched items... |
| `kn/validator1_kn.csv` | Kannada validator, 83 items | ...and to the Marathi file. 82/82 naturalness scores identical across Tamil/Marathi/Kannada despite genuinely different per-language prompts. |

## How to verify the cross-language copy-paste

```bash
python -c "
import pandas as pd
ta = pd.read_csv('ta/validator1_ta.csv')
mr = pd.read_csv('mr/validator1_mr.csv')
kn = pd.read_csv('kn/validator1_kn.csv')
for d in (ta, mr, kn):
    d['key'] = d['variant_id'].str.split('__').str[0] + '|' + d['attack_vector']
    d.set_index('key', inplace=True)
common = ta.index.intersection(mr.index).intersection(kn.index)
print(f'Common (seed × vector) keys: {len(common)}')
matches = sum(1 for k in common if ta.loc[k,'naturalness_1to5'] == mr.loc[k,'naturalness_1to5'] == kn.loc[k,'naturalness_1to5'])
print(f'Identical naturalness across ta/mr/kn: {matches}/{len(common)}')
"
```

Expected output: `82/82`.

## How to verify the rubber-stamping

```bash
python -c "
import pandas as pd
df = pd.read_csv('te/validator1_te.csv')
print(f'Naturalness std: {df[\"naturalness_1to5\"].std():.3f}')
print(f'Comment rows with score < 4 on any axis: {((df[[\"naturalness_1to5\",\"equivalence_1to5\",\"attack_validity_1to5\"]] < 4).any(axis=1) & df[\"comment\"].notna()).sum()}')
"
```

Expected: naturalness std = 0.000; 0 comment-rows with sub-4 scores (the one critical comment was paired with 5/5/3).

## Why these files are in the package

The taxonomy in Appendix X is a *paper-worthy contribution* — no prior Indic-NLP work has documented these failure modes at this granularity. Including the raw evidence here lets reviewers verify the claim rather than take our word.

The contaminated data is NOT used in the v3 primary validation. The LLM-ensemble protocol (see `../results/PANEL_REPORT.md`) is the v3 source of truth.
