# Methodology documents

The canonical copies of the v3 methodology documents live in `docs/` at the repository root and are referenced from the paper. This directory previously held byte-identical duplicates, which were removed in the v3 MAJOR REVISION pass per external-validator dedupe recommendation. The pointers below are the authoritative locations.

| Document | Canonical path | What it is |
|---|---|---|
| `VALIDATION_PROTOCOL.md` | `docs/VALIDATION_PROTOCOL.md` | The Likert 1–5 three-axis validation protocol (naturalness, semantic equivalence, attack-vector validity) followed by the LLM-judge ensemble in §4.6. |
| `VALIDATION_VERDICT.md` | `docs/VALIDATION_VERDICT.md` | The v3 verdict on the initial human-rating pilot and the pivot to LLM-primary validation. |
| `APPENDIX_X_RATER_FAILURES.md` | `docs/APPENDIX_X_RATER_FAILURES.md` | Source document for Appendix X (rater-failure taxonomy: rubber-stamping, cross-language copy-paste). |
| `FUNDING_REQUEST.md` | `docs/FUNDING_REQUEST.md` | Scoped funding request for v4 ground-truth replication (Karya-style ethical-crowd). |
